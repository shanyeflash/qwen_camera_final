import torch
import nodes
from .camera_presets import CAMERA_MODELS, FILM_STYLES, EFFECTS_PRESETS, THREE_VIEW_PRESETS

class QWENCameraPro:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "启用控制": ("BOOLEAN", {"default": True}),
                
                # 基础相机控制
                "拍摄模式": (["标准模式", "人物肖像", "产品展示", "建筑场景", "自然风光"], {"default": "标准模式"}),
                
                # 移动控制
                "移动方向": (["不移动", "向前", "向后", "向左", "向右", "向上", "向下"], {"default": "不移动"}),
                "移动距离": ("INT", {"default": 0, "min": 0, "max": 100, "step": 5, "display": "slider"}),
                
                # 旋转控制
                "左右旋转": ("INT", {"default": 0, "min": -180, "max": 180, "step": 5, "display": "slider"}),
                "上下倾斜": ("INT", {"default": 0, "min": -90, "max": 90, "step": 5, "display": "slider"}),
                
                # 镜头系统
                "镜头类型": ([
                    "标准镜头", "广角镜头", "长焦镜头", "特写镜头", 
                    "俯视镜头", "仰视镜头", "鱼眼镜头", "微距镜头"
                ], {"default": "标准镜头"}),
                
                # 三视图系统
                "三视图模式": (list(THREE_VIEW_PRESETS.keys()), {"default": "无"}),
                
                # 增强功能
                "相机型号": (list(CAMERA_MODELS.keys()), {"default": "自动"}),
                "胶片风格": (list(FILM_STYLES.keys()), {"default": "无"}),
                "画面特效": (list(EFFECTS_PRESETS.keys()), {"default": "无"}),
                
                # 画质增强
                "画质提升": (["标准", "高品质", "超高细节", "专业级"], {"default": "标准"}),
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("提示词",)
    FUNCTION = "generate_prompt"
    CATEGORY = "QWEN相机"

    def generate_prompt(self, 启用控制, 拍摄模式, 移动方向, 移动距离, 左右旋转, 上下倾斜, 
                      镜头类型, 三视图模式, 相机型号, 胶片风格, 画面特效, 画质提升):
        if not 启用控制:
            return ("",)
        
        prompt_parts = []
        
        # 处理画质提升
        quality_map = {
            "标准": "",
            "高品质": "最高画质，大师级作品，8K分辨率",
            "超高细节": "超高细节，锐利焦点，专业摄影",
            "专业级": "专业摄影，商业级质量，极致细节"
        }
        if 画质提升 != "标准":
            prompt_parts.append(quality_map[画质提升])
        
        # 处理相机型号
        if 相机型号 != "自动":
            prompt_parts.append(CAMERA_MODELS[相机型号])
        
        # 处理拍摄模式预设
        if 拍摄模式 != "标准模式":
            mode_config = self.get_mode_config(拍摄模式)
            # 只有当用户没有手动设置时才应用预设
            if 移动方向 == "不移动" and mode_config.get("移动方向"):
                移动方向 = mode_config["移动方向"]
            if 移动距离 == 0 and mode_config.get("移动距离"):
                移动距离 = mode_config["移动距离"]
            if 左右旋转 == 0 and mode_config.get("左右旋转"):
                左右旋转 = mode_config["左右旋转"]
            if 上下倾斜 == 0 and mode_config.get("上下倾斜"):
                上下倾斜 = mode_config["上下倾斜"]
            if 镜头类型 == "标准镜头" and mode_config.get("镜头类型"):
                镜头类型 = mode_config["镜头类型"]
        
        # 处理三视图模式
        three_view_prompt = ""
        if 三视图模式 != "无":
            three_view_config = THREE_VIEW_PRESETS[三视图模式]
            if 三视图模式 == "三视图组合":
                three_view_prompt = "正面视图，侧面视图，背面视图，多角度展示"
            else:
                # 单个视图模式，覆盖旋转设置
                左右旋转 = three_view_config["rotation"]
                上下倾斜 = three_view_config["tilt"]
                three_view_prompt = three_view_config["description"]
        
        # 处理移动控制
        if 移动方向 != "不移动" and 移动距离 > 0:
            direction_map = {
                "向前": "将镜头向前移动",
                "向后": "将镜头向后移动", 
                "向左": "将镜头向左移动",
                "向右": "将镜头向右移动",
                "向上": "将镜头向上移动",
                "向下": "将镜头向下移动"
            }
            prompt_parts.append(f"{direction_map[移动方向]}{移动距离}")
        
        # 处理旋转控制
        if 左右旋转 > 0:
            prompt_parts.append(f"将镜头向左旋转{abs(左右旋转)}度")
        elif 左右旋转 < 0:
            prompt_parts.append(f"将镜头向右旋转{abs(左右旋转)}度")
        
        if 上下倾斜 > 0:
            prompt_parts.append(f"将镜头向上倾斜{abs(上下倾斜)}度")
        elif 上下倾斜 < 0:
            prompt_parts.append(f"将镜头向下倾斜{abs(上下倾斜)}度")
        
        # 处理三视图提示词
        if three_view_prompt:
            prompt_parts.append(three_view_prompt)
        
        # 处理镜头类型
        if 镜头类型 != "标准镜头":
            lens_map = {
                "广角镜头": "广角镜头",
                "长焦镜头": "长焦镜头",
                "特写镜头": "特写镜头",
                "俯视镜头": "俯视视角",
                "仰视镜头": "仰视视角",
                "鱼眼镜头": "鱼眼镜头效果",
                "微距镜头": "微距摄影"
            }
            prompt_parts.append(lens_map[镜头类型])
        
        # 处理胶片风格
        if 胶片风格 != "无":
            prompt_parts.append(FILM_STYLES[胶片风格])
        
        # 处理画面特效
        if 画面特效 != "无":
            prompt_parts.append(EFFECTS_PRESETS[画面特效])
        
        # 如果没有选择任何操作，使用默认提示词
        if not prompt_parts:
            return ("标准镜头视角",)
        
        # 组合提示词
        final_prompt = "，".join(prompt_parts)
        
        # 添加QWEN LORA触发词
        final_prompt += "。QWEN2509多角度LORA"
        
        return (final_prompt,)
    
    def get_mode_config(self, mode):
        configs = {
            "人物肖像": {
                "移动方向": "向前",
                "移动距离": 25,
                "左右旋转": 15,
                "上下倾斜": -5,
                "镜头类型": "长焦镜头"
            },
            "产品展示": {
                "移动方向": "向前", 
                "移动距离": 35,
                "上下倾斜": -10,
                "镜头类型": "特写镜头"
            },
            "建筑场景": {
                "移动方向": "向后",
                "移动距离": 50,
                "上下倾斜": -20,
                "镜头类型": "广角镜头"
            },
            "自然风光": {
                "移动方向": "向后",
                "移动距离": 60, 
                "镜头类型": "广角镜头"
            }
        }
        return configs.get(mode, {})

class QWENCameraAnimation:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "启用动画": ("BOOLEAN", {"default": True}),
                "动画帧数": ("INT", {"default": 4, "min": 2, "max": 10, "step": 1}),
                
                # 起始视角
                "起始旋转": ("INT", {"default": -45, "min": -180, "max": 180, "step": 5}),
                "起始倾斜": ("INT", {"default": 0, "min": -90, "max": 90, "step": 5}),
                
                # 结束视角
                "结束旋转": ("INT", {"default": 45, "min": -180, "max": 180, "step": 5}),
                "结束倾斜": ("INT", {"default": 0, "min": -90, "max": 90, "step": 5}),
                
                # 动画类型
                "动画类型": (["旋转", "推近", "拉远", "环绕", "升降"], {"default": "旋转"}),
                
                # 镜头设置
                "动画镜头": (["标准镜头", "广角镜头", "长焦镜头"], {"default": "标准镜头"}),
            }
        }
    
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("动画提示词",)
    FUNCTION = "generate_animation_prompt"
    CATEGORY = "QWEN相机"

    def generate_animation_prompt(self, 启用动画, 动画帧数, 起始旋转, 起始倾斜, 结束旋转, 
                               结束倾斜, 动画类型, 动画镜头):
        if not 启用动画:
            return ("",)
        
        # 根据动画类型生成描述
        animation_descriptions = {
            "旋转": f"从{起始旋转}度旋转到{结束旋转}度的平滑旋转动画",
            "推近": "镜头缓慢推近的动画效果", 
            "拉远": "镜头缓慢拉远的动画效果",
            "环绕": "环绕主体运动的动画",
            "升降": "镜头升降运动的动画效果"
        }
        
        animation_desc = animation_descriptions.get(动画类型, "动态相机动画")
        
        # 镜头描述
        lens_desc = ""
        if 动画镜头 != "标准镜头":
            lens_map = {
                "广角镜头": "广角镜头",
                "长焦镜头": "长焦镜头"
            }
            lens_desc = f"，{lens_map[动画镜头]}"
        
        # 生成动画提示词
        prompt = f"{animation_desc}{lens_desc}，{动画帧数}帧动画序列。QWEN2509多角度LORA"
        
        return (prompt,)

# 节点注册
NODE_CLASS_MAPPINGS = {
    "QWENCameraPro": QWENCameraPro,
    "QWENCameraAnimation": QWENCameraAnimation
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "QWENCameraPro": "🎬 QWEN专业相机",
    "QWENCameraAnimation": "🎞️ QWEN相机动画"
}